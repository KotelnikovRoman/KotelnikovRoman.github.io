/*script*/
$(function(){
    $(".active_menu").click(function(){
        $(".menu_input").toggleClass("show_menu");
        return false;
    });
});